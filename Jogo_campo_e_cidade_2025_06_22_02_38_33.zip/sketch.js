let truck;
let campoItems = [];
let cidadeItems = [];
let festaItems = [];
let truckSpeed = 5;
let entregues = 0;

function setup() {
  createCanvas(800, 400);
  truck = createVector(width / 2, height - 40);

  // Criar itens no campo (esquerda)
  for (let i = 0; i < 3; i++) {
    campoItems.push(createVector(random(50, 200), random(50, 350)));
  }

  // Criar itens na cidade (direita)
  for (let i = 0; i < 3; i++) {
    cidadeItems.push(createVector(random(600, 750), random(50, 350)));
  }
}

function draw() {
  background(220);

  // Campo
  fill(100, 200, 100);
  rect(0, 0, width / 3, height);
  fill(0);
  text("🌾 Campo", 20, 20);

  // Cidade
  fill(180, 180, 255);
  rect(2 * width / 3, 0, width / 3, height);
  fill(0);
  text("🏙️ Cidade", 700, 20);

  // Festa (meio)
  fill(255, 240, 180);
  rect(width / 3, 0, width / 3, height);
  fill(0);
  text("🎉 Festa!", width / 2 - 20, 20);

  // Mostrar itens do campo
  fill(255, 165, 0);
  for (let i = 0; i < campoItems.length; i++) {
    ellipse(campoItems[i].x, campoItems[i].y, 20);
  }

  // Mostrar itens da cidade
  fill(0, 100, 255);
  for (let i = 0; i < cidadeItems.length; i++) {
    ellipse(cidadeItems[i].x, cidadeItems[i].y, 20);
  }

  // Mostrar itens da festa
  fill(255, 0, 200);
  for (let i = 0; i < festaItems.length; i++) {
    ellipse(festaItems[i].x, festaItems[i].y, 15);
  }

  // Desenhar o caminhão
  fill(150, 0, 0);
  rect(truck.x, truck.y, 40, 20);

  fill(0);
  textSize(14);
  text(`Entregues: ${entregues}`, 10, height - 10);

  checkPickup();
}

function keyPressed() {
  if (keyCode === LEFT_ARROW && truck.x > 0) {
    truck.x -= truckSpeed;
  } else if (keyCode === RIGHT_ARROW && truck.x < width - 40) {
    truck.x += truckSpeed;
  } else if (keyCode === UP_ARROW && truck.y > 0) {
    truck.y -= truckSpeed;
  } else if (keyCode === DOWN_ARROW && truck.y < height - 20) {
    truck.y += truckSpeed;
  }
}

let carrying = null;

function checkPickup() {
  if (!carrying) {
    // Verifica se está colidindo com item do campo
    for (let i = 0; i < campoItems.length; i++) {
      if (dist(truck.x, truck.y, campoItems[i].x, campoItems[i].y) < 30) {
        carrying = campoItems.splice(i, 1)[0];
        break;
      }
    }

    // Verifica se está colidindo com item da cidade
    for (let i = 0; i < cidadeItems.length; i++) {
      if (dist(truck.x, truck.y, cidadeItems[i].x, cidadeItems[i].y) < 30) {
        carrying = cidadeItems.splice(i, 1)[0];
        break;
      }
    }
  } else {
    // Verifica se está na área da festa para entregar
    if (truck.x > width / 3 && truck.x < 2 * width / 3) {
      festaItems.push(createVector(truck.x, truck.y));
      carrying = null;
      entregues++;

      if (entregues >= 6) {
        fill(0, 255, 0);
        textSize(32);
        text("🎊 A festa começou! 🎊", width / 2 - 150, height / 2);
        noLoop();
      }
    }
  }
}



